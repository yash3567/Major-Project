import img1 from "../assets/img1.png"
import img2 from "../assets/img2.png"
import img3 from "../assets/img3.png"
import img4 from "../assets/img4.png"
import img5 from "../assets/img5.png"
import img6 from "../assets/img6.png"

const mywork_data = [
     {
        w_no:1,
        w_name:"TCS iON",
        w_img:img1
     },
     {
        w_no:2,
        w_name:"TCS MasterCraft",
        w_img:img2
     },
     {
        w_no:3,
        w_name:"Microsoft",
        w_img:img3
     },
     {
        w_no:4,
        w_name:"CodeChef",
        w_img:img4
     },
     {
        w_no:5,
        w_name:"Skill-India",
        w_img:img5
     },
     {
        w_no:6,
        w_name:"Nestle",
        w_img:img6
     },

]