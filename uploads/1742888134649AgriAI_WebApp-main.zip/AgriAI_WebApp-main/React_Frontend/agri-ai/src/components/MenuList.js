export const MenuList = [
    {
      title: "Home",
      url: "/",
    },
    {
      title: "Crop Recommender",
      url: "/crop",
    },
    {
      title: "Fertilizer Recommender",
      url: "/fertilizer",
    },
  ];